
  function setup() {
  createCanvas(600,600);
 
  }

  function draw() {

  background(30);
  translate(150,-50);
    
  noStroke();
    
  blendMode(LIGHTEST);
    
    //PLANT (LEAVES)
  push()
  translate(0,-10.5);
    
  fill(0, 128, 64);
  triangle(100, 510, 130, 280, 200, 510);

  fill(0, 204,102);
  triangle(100, 510, 45, 300, 200, 510);
    
  fill(0, 179, 89);
  triangle(100, 510, 145, 300, 200, 510);

  fill(0, 230,115);
  triangle(100, 510, 225, 350, 200, 510);

  fill(0, 153, 77)
  triangle(100, 510, 255, 400, 200, 510);

  fill(0, 77, 0);
  triangle(100, 510, 235, 460, 200, 510);

  fill(0, 77, 0);
  triangle(100, 310, 115, 460, 200, 510);
    
  fill(0, 77, 0);
  triangle(100, 510,245, 360, 200, 510);

  fill(0, 77,0);
  triangle(100, 510, 45, 450, 200, 510);

  pop()

  // POT
 
  push()
    
  translate(-5,0);
    
  stroke (0, 179, 0);
  strokeWeight(2);
  fill( 265, 120, 90);
  quad(65, 500, 246, 500, 210, 600, 100, 600);

  pop()
 

}